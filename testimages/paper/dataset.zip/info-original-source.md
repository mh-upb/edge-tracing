# Original Source

We have created this dataset based on the [BSDS500 dataset](https://github.com/BIDS/BSDS500).

## Corresponding Paper

For more detailed information on the original dataset, please refer to the following paper:

*Contour Detection and Hierarchical Image Segmentation*. P. Arbelaez, M. Maire, C. Fowlkes, and J. Malik. IEEE TPAMI, Vol. 33, No. 5, pp. 898-916, May 2011.
